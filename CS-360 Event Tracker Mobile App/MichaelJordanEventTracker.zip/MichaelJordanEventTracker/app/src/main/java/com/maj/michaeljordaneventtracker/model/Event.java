package com.maj.michaeljordaneventtracker.model;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

@Entity(tableName = "events",
        foreignKeys = @ForeignKey(entity = User.class,
                                  parentColumns = "username",
                                  childColumns = "user"))
public class Event implements Comparable<Event>{

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int mId;

    @ColumnInfo(name = "loc")
    private String mLocation;

    @ColumnInfo(name = "desc")
    private String mDescription;

    @ColumnInfo(name = "time")
    private String mTime;

    @ColumnInfo(name = "date")
    private String mDate;

    @ColumnInfo(name = "user")
    private String mUsername;

    public Event() {

    }

    public String getLocation() {
        return mLocation;
    }

    public void setLocation(String mLocation) {
        this.mLocation = mLocation;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    public String getTime() {
        return mTime;
    }

    public void setTime(String mTime) {
        this.mTime = mTime;
    }

    public int getId() {
        return mId;
    }

    public void setId(int mId) {
        this.mId = mId;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String mDate) {
        this.mDate = mDate;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(String username) {
        this.mUsername = username;
    }

    @Override

    public int compareTo(Event o) {
        SimpleDateFormat fm = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        try {
            return fm.parse(this.mTime).compareTo(fm.parse(o.mTime));
        } catch (ParseException e) {
            return 0;
        }
    }
}
