package com.maj.michaeljordaneventtracker;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.Calendar;

public class DatePickerFragment extends DialogFragment {
    private DatePickerDialog.OnDateSetListener mListener;


    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState){
        Calendar c = Calendar.getInstance();
        Bundle args = getArguments();
        int year = args.getInt("YEAR", c.get(Calendar.YEAR));
        int month = args.getInt("MONTH", c.get(Calendar.MONTH));
        int day = args.getInt("DAY", c.get(Calendar.DAY_OF_MONTH));

        return new DatePickerDialog(getActivity(), mListener, year, month, day);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if(!(context instanceof DatePickerDialog.OnDateSetListener)) {
            throw new IllegalStateException("Activity must implement DatePicker callbacks");
        }

        mListener = (DatePickerDialog.OnDateSetListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();

        mListener = null;
    }
}
