package com.maj.michaeljordaneventtracker;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class EventFragment extends DialogFragment {
    //adapted from https://medium.com/alexander-schaefer/implementing-the-new-material-design-full-screen-dialog-for-android-e9dcc712cb38

    private Toolbar mToolbar;
    private EditText mEditLocation;
    private EditText mEditTime;
    private EditText mEditDescription;
    private String mCurDate;
    public final static String KEY_EVENT_FRAGMENT = "eventCreated";
    public final static String KEY_EVENT_TIME = "eventTime";
    public final static String KEY_EVENT_LOCATION = "eventLocation";
    public final static String KEY_EVENT_DESCRIPTION = "eventDescription";


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.AppTheme_FullScreenDialog);
        Bundle args = getArguments();
        mCurDate = args.getString(EventActivity.KEY_CUR_DATE);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_event, container, false);
        mToolbar = view.findViewById(R.id.toolbar);
        mEditLocation = view.findViewById(R.id.addEventLocationText);
        mEditDescription = view.findViewById(R.id.addEventDescriptionText);
        mEditTime = view.findViewById(R.id.addEventTimeText);
        TextView mDateInfo = view.findViewById(R.id.addEventDateText);
        LocalDate date = LocalDate.parse(mCurDate);
        mDateInfo.setText(getString(R.string.date_context, date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))));
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setLayout(width, height);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mToolbar.setNavigationOnClickListener(v -> dismiss());
        mToolbar.setTitle(getString(R.string.add_event_title));
        mToolbar.setTitleTextColor(ContextCompat.getColor(this.getContext(), R.color.white));
        mToolbar.setNavigationIcon(R.drawable.outline_close_24);
        mToolbar.inflateMenu(R.menu.event_dialog_menu);
        mToolbar.setOnMenuItemClickListener(item -> {

            String timeText = mEditTime.getText().toString().trim().toUpperCase();
            String locationText = mEditLocation.getText().toString().trim();
            String descriptionText = mEditDescription.getText().toString().trim();
            //ensure that the time is correctly formatted before creating the event
            //location and description may be empty by design
            if(!TrackerUtil.validateTime(timeText)) {
                new AlertDialog.Builder(EventFragment.this.getContext())
                        .setTitle(R.string.failure_title)
                        .setMessage(getString(R.string.invalid_time, getString(R.string.time_placeholder)))
                        .setPositiveButton(R.string.confirmed, null)
                        .show();
            } else {
                Bundle result = new Bundle();
                result.putString(KEY_EVENT_DESCRIPTION, descriptionText);
                result.putString(KEY_EVENT_LOCATION, locationText);
                result.putString(KEY_EVENT_TIME, timeText);
                getParentFragmentManager().setFragmentResult(KEY_EVENT_FRAGMENT, result);
                //Hide the soft keyboard for better user experience
                ((InputMethodManager)getContext().getSystemService(Context.INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(view.getWindowToken(), 0);
                dismiss();
            }
            return true;
        });
    }


}
