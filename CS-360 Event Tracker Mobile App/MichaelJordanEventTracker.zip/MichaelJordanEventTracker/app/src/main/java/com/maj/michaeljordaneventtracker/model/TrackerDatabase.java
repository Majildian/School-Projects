package com.maj.michaeljordaneventtracker.model;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Event.class, User.class}, version = 1, exportSchema = false)
public abstract class TrackerDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "tracker.db";

    protected static TrackerDatabase mTrackerDatabase;

    public static TrackerDatabase getInstance(Context context){
        if(mTrackerDatabase == null) {
            mTrackerDatabase = Room.databaseBuilder(context, TrackerDatabase.class, DATABASE_NAME).
                    allowMainThreadQueries()
                    .build();
        }
        return mTrackerDatabase;
    }

    public abstract EventDao eventDao();
    public abstract UserDao userDao();
}
