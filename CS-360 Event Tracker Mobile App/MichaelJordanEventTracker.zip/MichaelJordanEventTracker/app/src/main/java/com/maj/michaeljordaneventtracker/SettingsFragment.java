package com.maj.michaeljordaneventtracker;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.preference.Preference;
import androidx.preference.PreferenceManager;

import androidx.preference.PreferenceFragmentCompat;

import com.maj.michaeljordaneventtracker.model.Event;
import com.maj.michaeljordaneventtracker.model.TrackerDatabase;
import com.maj.michaeljordaneventtracker.notifications.BootReceiver;

import java.util.List;

public class SettingsFragment extends PreferenceFragmentCompat
       implements SharedPreferences.OnSharedPreferenceChangeListener {

    public static final String PREFERENCE_PHONE_NUMBER = "pref_phone_number";
    public static final String PREFERENCE_NOTIFICATIONS = "pref_notifications";
    public static final int REQUEST_SMS_CODE = 0;
    public static final int REQUEST_ALARM_CODE = 1;

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        // Load the preferences from an XML resource
        setPreferencesFromResource(R.xml.preferences, rootKey);

        // Access the default shared prefs
        SharedPreferences sharedPrefs =
                PreferenceManager.getDefaultSharedPreferences(getActivity());


        setPrefSummaryPhoneNumber(sharedPrefs);
    }

    private void setPrefSummaryPhoneNumber(SharedPreferences sharedPrefs) {
        String number = sharedPrefs.getString(PREFERENCE_PHONE_NUMBER, "").trim();
        Preference numberPref = findPreference(PREFERENCE_PHONE_NUMBER);
        numberPref.setEnabled(sharedPrefs.getBoolean(PREFERENCE_NOTIFICATIONS, false));
        if (number.length() == 0) {
            numberPref.setSummary(getResources().getString(R.string.pref_description_phone_number));
        }
        else {
            numberPref.setSummary(number);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onPause() {
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (key.equals(PREFERENCE_PHONE_NUMBER)) {
            setPrefSummaryPhoneNumber(sharedPreferences);
        } else if(key.equals(PREFERENCE_NOTIFICATIONS)) {

            if (sharedPreferences.getBoolean(PREFERENCE_NOTIFICATIONS, false)) {
                boolean hasSms = TrackerUtil.hasPermissions(this.getActivity(), Manifest.permission.SEND_SMS, R.string.sms_rationale, REQUEST_SMS_CODE);
                boolean hasExact = false;
                Context context = getContext();
                PackageManager pm = context.getPackageManager();
                ComponentName receiver;

                if(Build.VERSION.SDK_INT >= 31) {
                    hasExact = TrackerUtil.hasPermissions(this.getActivity(), Manifest.permission.SCHEDULE_EXACT_ALARM, R.string.alarm_rationale, REQUEST_ALARM_CODE);
                }
                if(hasSms){
                    if(!hasExact){
                        //app is running on android < 31, need to start timers for existing events here instead of in
                        //permissions receiver
                        TrackerDatabase database = TrackerDatabase.getInstance(context);
                        List<Event> eventList = database.eventDao().getEvents();
                        for (Event event : eventList) {
                            TrackerUtil.scheduleEvent(getContext(), event);
                        }
                    }
                    receiver = new ComponentName(getContext(), BootReceiver.class);
                    pm.setComponentEnabledSetting(receiver, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
                }
            }
            setPrefSummaryPhoneNumber(sharedPreferences);

        }
    }

}
