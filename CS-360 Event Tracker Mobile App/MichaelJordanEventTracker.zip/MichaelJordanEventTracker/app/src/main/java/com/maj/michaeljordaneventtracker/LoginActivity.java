package com.maj.michaeljordaneventtracker;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.textfield.TextInputEditText;
import com.maj.michaeljordaneventtracker.model.TrackerDatabase;
import com.maj.michaeljordaneventtracker.model.User;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText mUsernameText;
    private TextInputEditText mPasswordText;
    private TrackerDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mUsernameText = findViewById(R.id.usernameText);
        mPasswordText = findViewById(R.id.passwordText);
        mDatabase = TrackerDatabase.getInstance(this);
    }

    public void onLogin(View view) {
        String username = mUsernameText.getText().toString();
        String password = mPasswordText.getText().toString();
        if(!validateInput(username, password)){
            return;
        }
        if(mDatabase.userDao().getUser(username, password) != null){
            //user exists, move to event screen
            changeScreen(username);
        } else {
            //user doesn't exist or invalid password
            new AlertDialog.Builder(this)
                    .setTitle(R.string.failure_title)
                    .setMessage(R.string.login_failure_message)
                    .setPositiveButton(R.string.confirmed, null)
                    .show();
            mUsernameText.setText("");
            mPasswordText.setText("");
        }
    }

    public void onRegister(View view) {
        final String username = mUsernameText.getText().toString();
        final String password = mPasswordText.getText().toString();
        if(!validateInput(username, password)){
            return;
        }
        if(mDatabase.userDao().getUser(username) != null) {
            //user already exists, don't attempt to create it again
            new AlertDialog.Builder(this)
                    .setTitle(R.string.failure_title)
                    .setMessage(R.string.register_failure_message)
                    .setPositiveButton(R.string.confirmed, null)
                    .show();
            mUsernameText.setText("");
            mPasswordText.setText("");
        } else {
            //add user to database and move to event screen
            mDatabase.userDao().insertUser(new User(username, password));
            if(mDatabase.userDao().getUser(username, password) != null) {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.register_success_title)
                        .setMessage(R.string.register_success_message)
                        .setPositiveButton(R.string.confirmed, (dialog, which) -> changeScreen(username))
                        .show();
            }
        }
    }

    private boolean validateInput(String username, String password) {
        AlertDialog dialog;
        if((dialog = validateUsername(username)) != null){
            dialog.show();
            return false;
        }
        if((dialog = validatePassword(password)) != null){
            dialog.show();
            return false;
        }
        return true;
    }

    private AlertDialog validateUsername(String username) {
        if(username.length() < 6) {
            return new AlertDialog.Builder(this)
                    .setTitle(R.string.failure_title)
                    .setMessage(R.string.username_error_message)
                    .setPositiveButton(R.string.confirmed, null)
                    .create();
        }
        return null;
    }

    private AlertDialog validatePassword(String password) {
        if(password.length() < 8) {
            return new AlertDialog.Builder(this)
                    .setTitle(R.string.failure_title)
                    .setMessage(R.string.password_error_message)
                    .setPositiveButton(R.string.confirmed, null)
                    .create();
        }
        return null;
    }

    private void changeScreen(String username) {
        mUsernameText.setText("");
        mPasswordText.setText("");
        Intent intent = new Intent(LoginActivity.this, EventActivity.class);
        intent.putExtra(EventActivity.KEY_CUR_USER, username);
        startActivity(intent);
    }
}