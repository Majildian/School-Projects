package com.maj.michaeljordaneventtracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;

import com.maj.michaeljordaneventtracker.model.TrackerDatabase;
import com.maj.michaeljordaneventtracker.notifications.BootReceiver;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Display the fragment as the main content
        getSupportFragmentManager()
                .beginTransaction()
                .replace(android.R.id.content, new SettingsFragment())
                .commit();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch(requestCode) {
            case SettingsFragment.REQUEST_ALARM_CODE:
                //fall through to SMS code
            case SettingsFragment.REQUEST_SMS_CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_DENIED) {
                    //cancel all existing alarms
                    TrackerUtil.cancelEvents(TrackerDatabase.getInstance(this), this);

                    //disable both the boot receiver and the permissions receiver
                    ComponentName receiver = new ComponentName(this, BootReceiver.class);
                    PackageManager pm = getPackageManager();
                    pm.setComponentEnabledSetting(receiver, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, 0);

                    //set notification switch to false again and rebuild the settings fragment
                    PreferenceManager.getDefaultSharedPreferences(this)
                            .edit()
                            .putBoolean(SettingsFragment.PREFERENCE_NOTIFICATIONS, false)
                            .apply();
                    recreate();
                }

        }
    }
}