package com.maj.michaeljordaneventtracker.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class User {

    @ColumnInfo(name = "username")
    @PrimaryKey
    @NonNull
    private String mUsername;

    // Password stored in plaintext for now - in production quality app this is
    // a terrible idea.
    @ColumnInfo(name = "password")
    private String mPassword;

    public User(@NonNull String username, String password) {
        this.mUsername = username;
        this.mPassword = password;
    }

    @NonNull
    public String getUsername() {
        return mUsername;
    }

    public void setUserName(@NonNull String username) {
        this.mUsername = username;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        this.mPassword = password;
    }
}
