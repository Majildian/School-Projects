package com.maj.michaeljordaneventtracker;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import com.maj.michaeljordaneventtracker.model.Event;
import com.maj.michaeljordaneventtracker.model.TrackerDatabase;
import com.maj.michaeljordaneventtracker.notifications.AlarmReceiver;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class TrackerUtil {

    public static void scheduleEvent(Context context, Event event){
        if(ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED){
            // app doesn't have permission to send sms, don't schedule alarms for them.
            return;
        }
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        if(!prefs.getBoolean(SettingsFragment.PREFERENCE_NOTIFICATIONS, false)){
            // user doesn't want notifications, don't schedule alarms for them.
            return;
        }
        DateTimeFormatter fm = DateTimeFormatter.ofPattern("h:m a", Locale.getDefault());

        LocalDateTime eventTime = LocalTime.parse(event.getTime(), fm).atDate(LocalDate.parse(event.getDate()));
        if(eventTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() <= System.currentTimeMillis()){
            //Event already happened, don't set a timer for it.
            return;
        }
        eventTime = eventTime.minusHours(10);
        long eventMillis = eventTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();

        Intent nIntent = new Intent(context, AlarmReceiver.class);
        nIntent.putExtra(AlarmReceiver.KEY_EVENT_ID, event.getId());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, event.getId(), nIntent, 0);

        ((AlarmManager)context.getSystemService(Context.ALARM_SERVICE))
                .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, eventMillis, pendingIntent);
    }

    public static void cancelEvents(TrackerDatabase database, Context context) {
        List<Event> eventList = database.eventDao().getEvents();
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        for (Event e : eventList) {
            Intent intent = new Intent(context, AlarmReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, e.getId(), intent, 0);
            manager.cancel(pendingIntent);
        }
    }

    public static boolean validateTime(String in){
        //make sure that entered time data is in the correct format for our sorting algorithm
        return in.matches("(\\A1[012]|\\A[\\d&&[^0]]):[012345]\\d\\s[AP]M\\Z");
    }

    public static boolean hasPermissions(final Activity activity, final String permission,
                                         int rationaleMessageId, final int requestCode) {
        // See if permission is granted
        if (ContextCompat.checkSelfPermission(activity, permission)
                != PackageManager.PERMISSION_GRANTED) {

            // Explain why permission needed?
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {

                // Show why permission is needed
                showPermissionRationaleDialog(activity, rationaleMessageId, (dialog, which) -> {

                    // Request permission again
                    ActivityCompat.requestPermissions(activity,
                            new String[] { permission }, requestCode);
                });
            }
            else {
                // Request permission
                ActivityCompat.requestPermissions(activity,
                        new String[] { permission }, requestCode);
            }
            return false;
        }
        return true;
    }

    private static void showPermissionRationaleDialog(Activity activity, int messageId,
                                                      DialogInterface.OnClickListener onClickListener) {
        // Show dialog explaining why permission is needed
        new AlertDialog.Builder(activity)
                .setTitle(R.string.permission_needed)
                .setMessage(messageId)
                .setPositiveButton(R.string.confirmed, onClickListener)
                .create()
                .show();
    }
}
