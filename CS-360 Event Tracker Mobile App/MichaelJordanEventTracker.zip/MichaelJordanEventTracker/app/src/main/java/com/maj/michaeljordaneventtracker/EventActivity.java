package com.maj.michaeljordaneventtracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.maj.michaeljordaneventtracker.model.Event;
import com.maj.michaeljordaneventtracker.model.TrackerDatabase;
import com.maj.michaeljordaneventtracker.notifications.AlarmReceiver;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Collections;
import java.util.List;

public class EventActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    private RecyclerView mRecyclerView;
    private EventAdapter mEventAdapter;
    private String mUsername;
    private String mCurDate;
    private TrackerDatabase mDatabase;
    public final static String KEY_CUR_USER = "currentUser";
    public final static String KEY_CUR_DATE = "currentDate";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_event);


        //make sure we have the logged in username
        if(savedInstanceState != null) {
            mUsername = savedInstanceState.getString(KEY_CUR_USER);
            mCurDate = savedInstanceState.getString(KEY_CUR_DATE);
        } else if(getIntent().getStringExtra(KEY_CUR_USER) == null) {
            // hack to maintain user name through settings screen
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            mUsername = prefs.getString(KEY_CUR_USER, "");
            mCurDate = prefs.getString(KEY_CUR_DATE, "");
            SharedPreferences.Editor editor = prefs.edit();
            editor.remove(KEY_CUR_DATE);
            editor.remove(KEY_CUR_USER);
            editor.apply();
        } else {
            mUsername = getIntent().getStringExtra(KEY_CUR_USER);
            mCurDate = LocalDate.now().toString();
        }

        mDatabase = TrackerDatabase.getInstance(this);
        mRecyclerView = findViewById(R.id.eventRecyclerView);

        //set up the grid manager
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        //set up listener for the event creation fragment result
        getSupportFragmentManager().setFragmentResultListener(EventFragment.KEY_EVENT_FRAGMENT, this, (key, bundle) -> {
            Event created = new Event();
            created.setTime(bundle.getString(EventFragment.KEY_EVENT_TIME));
            created.setLocation(bundle.getString(EventFragment.KEY_EVENT_LOCATION));
            created.setDescription(bundle.getString(EventFragment.KEY_EVENT_DESCRIPTION));
            created.setDate(mCurDate);
            created.setUsername(mUsername);
            //add to db
            mDatabase.eventDao().insertEvent(created);
            //"created" variable does not have the necessary ID set to properly schedule notification
            //must get the variable from the database to do so
            //compare on all fields to reduce the chance of a collision
            //set created variable to the event from database for efficiency when removing from view
            for(Event e : mDatabase.eventDao().getEvents()){
                if(e.getTime().equals(created.getTime())
                        && e.getDescription().equals(created.getDescription())
                        && e.getDate().equals(created.getDate())
                        && e.getLocation().equals(created.getLocation())
                        && e.getUsername().equals(created.getUsername())){
                    created = e;
                    break;
                }
            }
            //add to view
            mEventAdapter.addEvent(created);
            TrackerUtil.scheduleEvent(this, created);


        });

        changeDate();
        //if there is an existing event when the user logs in, the keyboard will pop up.
        //by requesting focus on the FAB, we can avoid this.
        findViewById(R.id.addEventButton).requestFocus();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.event_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        if(item.getItemId() == R.id.settings){
            SharedPreferences.Editor prefs = PreferenceManager.getDefaultSharedPreferences(this).edit();
            prefs.putString(KEY_CUR_USER, mUsername);
            prefs.putString(KEY_CUR_DATE, mCurDate);
            prefs.apply();
            Intent intent = new Intent(EventActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        } else if(item.getItemId() == R.id.calendar){
            DatePickerFragment newFragment = new DatePickerFragment();

            LocalDate curDate = LocalDate.parse(mCurDate);
            Bundle args = new Bundle();
            args.putInt("YEAR", curDate.getYear());
            // DatePickerDialog is compatible with Calendar months, which are offset from LocalDate months.
            // For the correct value, we subtract 1 from the LocalDate month.
            args.putInt("MONTH", curDate.getMonthValue()-1);
            args.putInt("DAY", curDate.getDayOfMonth());

            newFragment.setArguments(args);
            newFragment.show(getSupportFragmentManager(), "datePicker");
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(KEY_CUR_USER, mUsername);
        outState.putString(KEY_CUR_DATE, mCurDate);
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        // DatePickerDialog is compatible with Calendar months, which are offset from LocalDate months.
        // For the correct value, we add 1 to the Calendar month.
        mCurDate = LocalDate.of(year, month+1, dayOfMonth).toString();
        changeDate();
    }

    public void onAddEvent(View view) {
        EventFragment newFragment = new EventFragment();

        //Send date to fragment to provide information to user
        Bundle args = new Bundle();
        args.putString(KEY_CUR_DATE, mCurDate);
        newFragment.setArguments(args);

        newFragment.show(getSupportFragmentManager(), "eventMaker");
    }

    private void changeDate() {
        //set the action bar title to the correct day
        getSupportActionBar().setTitle(LocalDate.parse(mCurDate).format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)));

        //obtain events for current date
        List<Event> currentEvents = mDatabase.eventDao().getEvents(mCurDate, mUsername);
        Collections.sort(currentEvents);

        //build the adapter and attach it
        mEventAdapter = new EventAdapter(currentEvents);
        mRecyclerView.setAdapter(mEventAdapter);
    }

    private class EventHolder extends RecyclerView.ViewHolder{

        private final EditText mEditTime;
        private final EditText mEditLocation;
        private final EditText mEditDescription;
        private final ImageButton mDeleteButton;
        private final ImageButton mSaveButton;

        public EventHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            mEditTime = itemView.findViewById(R.id.timeInputText);
            mEditLocation = itemView.findViewById(R.id.locationInputText);
            mEditDescription = itemView.findViewById(R.id.descriptionInputText);
            mDeleteButton = itemView.findViewById(R.id.deleteButton);
            mSaveButton = itemView.findViewById(R.id.saveButton);
        }

        public void bind(Event event, int position) {
            mEditTime.setText(event.getTime());
            mEditLocation.setText(event.getLocation());
            mEditDescription.setText(event.getDescription());


            mDeleteButton.setOnClickListener(v -> {
                //remove from db
                mDatabase.eventDao().deleteEvent(event);
                //remove from view
                mEventAdapter.removeEvent(event);
                //remove from notifications
                Intent intent = new Intent(EventActivity.this, AlarmReceiver.class);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(EventActivity.this, event.getId(), intent, 0);
                ((AlarmManager)EventActivity.this.getSystemService(Context.ALARM_SERVICE)).cancel(pendingIntent);

                //Hide the soft keyboard for better user experience
                ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(mSaveButton.getWindowToken(), 0);
            });

            mSaveButton.setOnClickListener(v -> {
                String timeText = mEditTime.getText().toString().trim().toUpperCase();
                String locationText = mEditLocation.getText().toString().trim();
                String descriptionText = mEditDescription.getText().toString().trim();
                if(!TrackerUtil.validateTime(timeText)) {
                    new AlertDialog.Builder(EventActivity.this)
                            .setTitle(R.string.failure_title)
                            .setMessage(getString(R.string.invalid_time, getString(R.string.time_placeholder)))
                            .setPositiveButton(R.string.confirmed, null)
                            .show();
                } else {
                    event.setDescription(descriptionText);
                    event.setLocation(locationText);
                    event.setTime(timeText);
                    mDatabase.eventDao().updateEvent(event);
                    //change notification to reflect new time
                    TrackerUtil.scheduleEvent(EventActivity.this, event);
                    //Hide the soft keyboard for better user experience
                    ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                            .hideSoftInputFromWindow(mSaveButton.getWindowToken(), 0);
                    //remove and add the event to sort the view
                    mEventAdapter.removeEvent(event);
                    mEventAdapter.addEvent(event);
                    Toast.makeText(EventActivity.this, getString(R.string.save_toast, event.getTime()), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private class EventAdapter extends RecyclerView.Adapter<EventHolder> {
        private final List<Event> mEventList;

        public EventAdapter(List<Event> mEventList) {
            this.mEventList = mEventList;
        }


        @NonNull
        @Override
        public EventHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(EventActivity.this);
            return new EventHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull EventHolder holder, int position) {
            holder.bind(mEventList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mEventList.size();
        }

        public void addEvent(Event event) {
            //add event and sort the list so they are in temporal order
            mEventList.add(event);
            Collections.sort(mEventList);
            //find the index of the new event in the sorted list, update the view, and scroll to it
            int index = mEventList.indexOf(event);
            notifyItemInserted(index);
            mRecyclerView.scrollToPosition(index);
        }

        public void removeEvent(Event event) {
            int index = mEventList.indexOf(event);
            if (index >= 0) {
                mEventList.remove(event);
                notifyItemRemoved(index);
            }
        }
    }
}