package com.maj.michaeljordaneventtracker.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.SmsManager;

import androidx.preference.PreferenceManager;

import com.maj.michaeljordaneventtracker.SettingsFragment;
import com.maj.michaeljordaneventtracker.model.Event;
import com.maj.michaeljordaneventtracker.model.TrackerDatabase;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.List;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String KEY_EVENT_ID = "eventId";

    @Override
    public void onReceive(Context context, Intent intent) {
        TrackerDatabase database = TrackerDatabase.getInstance(context);
        List<Event> eventList = database.eventDao().getEvents(intent.getIntExtra(KEY_EVENT_ID, -1));
        if(eventList.size() == 0) return;
        Event triggeringEvent = eventList.get(0);
        String timeString = LocalDate.parse(triggeringEvent.getDate())
                .format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)) + " " + triggeringEvent.getTime();
        String descriptionString = triggeringEvent.getDescription();
        String locationString = triggeringEvent.getLocation();

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        String phoneNumber = prefs.getString(SettingsFragment.PREFERENCE_PHONE_NUMBER, "");
        if(phoneNumber.equals("")) return;
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null,
                String.format("%s : %s @ %s", timeString, descriptionString, locationString), null, null);
    }
}
