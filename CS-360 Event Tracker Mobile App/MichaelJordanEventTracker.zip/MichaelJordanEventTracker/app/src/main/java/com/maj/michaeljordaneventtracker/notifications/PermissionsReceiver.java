package com.maj.michaeljordaneventtracker.notifications;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.maj.michaeljordaneventtracker.TrackerUtil;
import com.maj.michaeljordaneventtracker.model.Event;
import com.maj.michaeljordaneventtracker.model.TrackerDatabase;

import java.util.List;

public class PermissionsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if(Build.VERSION.SDK_INT >= 31 && manager.canScheduleExactAlarms()) {
            //app doesn't have the correct permissions
            return;
        }
        TrackerDatabase database = TrackerDatabase.getInstance(context);
        List<Event> eventList = database.eventDao().getEvents();
        for (Event event : eventList) {
            TrackerUtil.scheduleEvent(context, event);
        }
    }


}