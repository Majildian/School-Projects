package com.maj.michaeljordaneventtracker.model;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface EventDao {
    @Query("SELECT * FROM events WHERE date = :date AND user = :username")
    List<Event> getEvents(String date, String username);

    @Query("SELECT * FROM events")
    List<Event> getEvents();

    @Query("SELECT * FROM events WHERE id = :id")
    List<Event> getEvents(int id);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    void insertEvent(Event event);

    @Update
    void updateEvent(Event event);

    @Delete
    void deleteEvent(Event event);
}
